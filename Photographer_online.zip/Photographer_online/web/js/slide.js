function displayButtons(){
    document.getElementById('playButton').style.display = 'block';
    document.getElementById('statusBar').style.display = 'block';
}

function hideButtons(){
    document.getElementById('playButton').style.display = 'none';
    document.getElementById('statusBar').style.display = 'none';
}

function changeSound() {
    if (document.getElementById('sound').className == 'fas fa-volume-up') {
        document.getElementById('sound').className = 'fas fa-volume-mute';
    } else {
        document.getElementById('sound').className = 'fas fa-volume-up';
    }
}

function changeStatus() {
    if (document.getElementById('bigIcon').className == 'fas fa-play') {
        document.getElementById('smallButton').className = 'fas fa-pause';
        document.getElementById('bigIcon').className = 'fas fa-pause';
        document.getElementById('btn').value = "Pause";
        play();
    } else {
        document.getElementById('smallButton').className = 'fas fa-play';
        document.getElementById('bigIcon').className = 'fas fa-play';
        document.getElementById('btn').value = "Play";
        pause();
    }
}
var imageIndex = 1;
var timeout;
timeout = setTimeout(play, 2000);
play();

function play() {
//    var listImages = document.getElementsByTagName('img');
     var listImages = document.getElementsByClassName("smallImg");
    //if index equals number of images then asign it the first image
    if (imageIndex === listImages.length) {
        imageIndex = 0;
    }
    var imageSrc = listImages[imageIndex].src;
    var indexImg = imageSrc.toString().indexOf('images');
    var imageAddess = imageSrc.toString().substring(indexImg);
    var show = document.getElementById('slideShow').style;
    document.getElementById('showing').src = imageAddess;
    show.backgroundColor = 'black';
    show.backgroundPosition = 'center';
    show.backgroundRepeat = 'no-repeat';
    show.backgroundSize = 'contain';
//    window.alert(imageSrc +" \n "+ imageAddess);
    imageIndex++;
    timeout = setTimeout(play, 2000);
}

function pause() {
    clearTimeout(timeout);
}

function toggleFullscreen(el) {
    if (document.fullscreenElement || document.mozFullScreenElement || document.webkitFullscreenElement || document.msFullscreenElement) {
        if (document.exitFullscreen) {
            document.exitFullscreen();
        } else if (document.mozCancelFullScreen) {
            document.mozCancelFullScreen();
        } else if (document.webkitExitFullscreen) {
            document.webkitExitFullscreen();
        } else if (document.msExitFullscreen) {
            document.msExitFullscreen();
        }
        el.style.height = '420px';
    } else {
        if (document.documentElement.requestFullscreen) {
            el.requestFullscreen();
        } else if (document.documentElement.mozRequestFullScreen) {
            el.mozRequestFullScreen();
        } else if (document.documentElement.webkitRequestFullscreen) {
            el.webkitRequestFullscreen();
        } else if (document.documentElement.msRequestFullscreen) {
            el.msRequestFullscreen();
        }
        el.style.height = '100%';
    }
}

function changeSize() {
    var screenSize = document.getElementById('screenSize');
    
    if (document.getElementById('screenChange').className == 'fas fa-expand') {
        document.getElementById('screenChange').className = 'fas fa-compress';
        screenSize.value = 'Exit';
        screenSize.style.left = '94%';
    } else {
        document.getElementById('screenChange').className = 'fas fa-expand';
        screenSize.value = 'FullScreen';
        screenSize.style.left = '86%';
    }
    var el = document.getElementById('slideShow');
    toggleFullscreen(el);
}