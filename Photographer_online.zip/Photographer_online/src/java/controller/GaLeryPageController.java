/**
 * Copyright(C) 2020, Tô Huyền Diệu
 * J3.L.P0017/ Photographer
 *
 * Record of change
 * DATE            AUTHOR              DESCRIPTION
 * 2020/03/02      Tô Huyền Diệu       Gallery page Controller
 */
package controller;

import dao.ContactDAO;
import dao.impl.ImageDAOImpl;
import entity.Image;
import java.io.IOException;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import dao.impl.ContactDAOImpl;
import dao.impl.GalleryDAOImpl;
import dao.GalleryDAO;
import javax.servlet.http.HttpSession;
import dao.ImageDAO;

/**
 * The class contains method process request The method will throw objects of
 * <code>javax.servlet.ServletException</code>, <code>java.io.IOException</code>, 
 * <code>java.sql.SQLException</code> if there is any error occurring when
 * selecting data
 *
 * @author Tô Huyền Diệu
 */
public class GaLeryPageController extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request. It is a <code>javax.servlet.http.HttpServletRequest</code> object
     * @param response servlet response. It is a <code>javax.servlet.http.HttpServletRequest</code> object
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try {
            ImageDAO photoDao = new ImageDAOImpl();
            GalleryDAO galeryDAO = new GalleryDAOImpl();
            ContactDAO contactDAO = new ContactDAOImpl();
            String galeryIDValue = request.getParameter("galeryID");
            String imgID = request.getParameter("imgID");
            boolean indexValid = true;
            int galeryID = 0;
            //check galeryID id
            try {
                if (galeryIDValue != null) {
                    galeryID = Integer.parseInt(galeryIDValue);

                } else {
                    // set default galeryID id
                    galeryID = 1;
                }
            } catch (NumberFormatException e) {
                request.setAttribute("error", "This galery is invalid!!");
                request.getRequestDispatcher("Error.jsp").forward(request, response);
            }

            int pageSize = 8;

            //count total result 
            int totalRecord = photoDao.countImage(galeryID);
            if (totalRecord <= 0) {
                request.setAttribute("error", "No image in galery!!");
                request.getRequestDispatcher("Error.jsp").forward(request, response);
            }
            int maxPage = totalRecord / pageSize;
            if ((totalRecord % pageSize) != 0) {
                maxPage++;
            }

            //get top 1 image of galeryID
            int image = 0;

            String pageIndex = request.getParameter("index");
            int index = 0;

            //check index page
            try {
                if (pageIndex != null) {
                    index = Integer.parseInt(pageIndex);
                } else {
                    index = 1;
                }
            } catch (NumberFormatException e) {
                request.setAttribute("error", "This page is invalid!!");
                request.getRequestDispatcher("Error.jsp").forward(request, response);
                //  indexValid = false;
            }
            
            if (indexValid == true && index > 0 && index <= maxPage) {
                //check image id valid
                try {
                    if (imgID != null) {
                        image = Integer.parseInt(imgID);
                    } else {
                        // set default image id
                        image = photoDao.getTop1ImageGalery(galeryID).getId();
                    }
                } catch (Exception e) {
                    request.setAttribute("error", "This image not found!!");
                }
                // check image in galeryID or not
                if (photoDao.getImageID(image, galeryID) != null) {
                    request.setAttribute("top1Galery", photoDao.getImageID(image, galeryID));
                } else {
                    request.setAttribute("error", "This image not found!!");
                }
            } else {
                request.setAttribute("error", "This page is invalid!!");
            }

            try {
                //get list image with paging 
                List<Image> imagelList = photoDao.getListImageWithPaging(galeryID, index, pageSize);
                request.setAttribute("listImage", imagelList);

            } catch (Exception ex) {
                request.setAttribute("error", "This galery is invalid!!");
            }
            HttpSession session = request.getSession();
            session.setAttribute("page", "gallery");
            session.setAttribute("id", galeryID);

            request.setAttribute("index", index);
            request.setAttribute("maxPage", maxPage);
            request.setAttribute("galeryID", galeryID);
            request.setAttribute("totalRecord", totalRecord);
            request.setAttribute("galery", galeryDAO.getGaleryByID(galeryID));

            //get top 3 galeryID
            request.setAttribute("top3", galeryDAO.getTop3Galery());
            //get contact infor
            request.setAttribute("contact", contactDAO.getContact());
            request.setAttribute("active", galeryIDValue);
            request.getRequestDispatcher("Gallery.jsp").forward(request, response);
        } catch (Exception ex) {
            request.setAttribute("error", ex);
            request.getRequestDispatcher("Error.jsp").forward(request, response);
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
