/**
 * Copyright(C) 2020, Tô Huyền Diệu
 * J3.L.P0017/ Photographer
 *
 * Record of change
 * DATE            AUTHOR              DESCRIPTION
 * 2020/02/25      Tô Huyền Diệu       Contact DAO
 */
package dao;

import entity.Contact;

/**
 * The class list method select, update information from Contact table in database.
 * The method will throw an object of <code> java.lang.Exception</code> class 
 * if there is any error occurring when selecting or updating data
 * 
 * @author Tô Huyền Diệu
 */
public interface ContactDAO {
    
    /**
     * Select Contact from Contact table in database. All information of contact will be return
     * The result contains a Contact with telephone, email, linkFace, link Googgle, shortIntro,
     *           address, city, country, linkMap, imageMain, iconFace, iconTwitter, iconGoogle, views
     * 
     * @return a <code>Contact</code> object. It is a <code>entity.Contact</code>
     * @throws Exception 
     */
    public Contact getContact() throws Exception;
    
    /**
     * Update views in Contact table in database. Create 1 view
     * 
     * @throws Exception 
     */
    public void updateView() throws Exception;
    
    /**
     * Select amount of views from Contact table in database
     * The result return amount of views
     * 
     * @return a number. It is <code>int</code> data type
     * @throws Exception 
     */
    public int getViews() throws Exception;
}
