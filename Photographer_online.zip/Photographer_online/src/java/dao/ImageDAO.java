/**
 * Copyright(C) 2020, Tô Huyền Diệu
 * J3.L.P0017/ Photographer
 *
 * Record of change
 * DATE            AUTHOR              DESCRIPTION
 * 2020/02/25      Tô Huyền Diệu       Image DAO
 */
package dao;

import entity.Image;
import java.util.List;

/**
 * The class list method select information from Image table in database.
 * The method will throw an object of <code> java.lang.Exception</code> class 
 * if there is any error occurring when selecting or updating data
 * 
 * @author Tô Huyền Diệu
 */
public interface ImageDAO {   
    
    /**
     * Select amount of Image by GalleryId from table Image in database.
     * The result contains a number. It is a <code>int</code> data type 
     * 
     * @param id the Gallery id. It is a <code>int</code> data type
     * @return a number. It is a <code>int</code> data type 
     * @throws Exception 
     */
    public int countImage(int id) throws Exception; 
    
    
    /**
     * Select top 1 link image by gallery id from table Image in database
     * The result contains a string is link of image. It is a <code>java.lang.String</code>
     * 
     * @param id the Gallery id. It is a <code>int</code> data type
     * @return a String. It is <code>java.lang.String</code> object
     * @throws Exception 
     */
    public String getImageByGaleryID(int id) throws Exception;
    
    /**
     * Select list Image by gallery id, page index and page size from table Image in database Photo.
     * The result contains a list of <code>Image</code> object
     * 
     * @param galeryID the gallery id. It is a <code>int</code> data type
     * @param pageIndex the page index. It is a <code>int</code> data type
     * @param pageSize the page size. It is a <code>int</code> data type
     * @return a list of <code>Image</code>. It is a <code>java.util.List</code> object
     * @throws Exception 
     */
    public List<Image> getListImageWithPaging(int galeryID, int pageIndex, int pageSize) throws Exception;
        
    /**
     * Select Image by Image id and gallery id from Image table in database.All information of a Image will be return 
     * The result contains a <code>Image</code> object with id, galleryID, link
     * 
     * @param id the Image id. It is a <code>int</code> data type
     * @param galeryId the gallery id. It is a <code>int</code> data type
     * @return a <code>Image</code> object. It is a <code>entity.Image</code>
     * @throws Exception 
     */
    public Image getImageID(int id, int galeryId) throws Exception;        
    
    /**
     * Select top 1 Image by gallery id. All information of Image will be return
     * The result contains a <code>Image</code> object with id, galleryID, link
     * 
     * @param galeryID the gallery id. It is a <code>int</code> data type
     * @return <code>Image</code> object. It is a <code>entity.Image</code>
     * @throws Exception 
     */
    public Image getTop1ImageGalery(int galeryID) throws Exception;
}