/**
 * Copyright(C) 2020, Tô Huyền Diệu
 * J3.L.P0017/ Photographer
 *
 * Record of change
 * DATE            AUTHOR              DESCRIPTION
 * 2020/02/25      Tô Huyền Diệu       Gallery DAO
 */
package dao;

import entity.Galery;
import java.util.List;

/**
 * The class list method select information from Gallery table in database.
 * The method will throw an object of <code> java.lang.Exception</code> class 
 * if there is any error occurring when selecting or updating data
 * 
 * @author Tô Huyền Diệu
 */
public interface GalleryDAO {
    
    /**
     * Select amount of Gallery from Gallery table in database
     * The result contains a number. It is a <code>int</code> data type  
     * 
     * @return a number. It is a <code>int</code> data type
     * @throws Exception 
     */
    public int count() throws Exception;  
    
    
    /**
     * Select top 3 Gallery from Gallery table in database. All information of Gallery will be return
     * The result contains a list of <code>Gallery</code> object 
     * 
     * @return a list of <code>Gallery</code> object. It is a <code>java.util.List</code> object
     * @throws Exception 
     */
    public List<Galery> getTop3Galery() throws Exception;
    
    
    /**
     * Select Gallery by its it. All information of Gallery will be return
     * The result contains a <code>Gallery</code> object with id, title, description, image
     * 
     * @param id the gallery id. It is a <code>int</code> data type
     * @return a <code>Gallery</code>. It is a <code>entity.Galery</code> object
     * @throws Exception 
     */
    public Galery getGaleryByID(int id) throws Exception;
    
    
    /**
     * Select list Gallery by page index and page size.
     * The result contains a list of<code>Gallery</code>
     * 
     * @param pageIndex the page index. It is a <code>int</code> data type
     * @param pageSize the page size. It is a <code>int</code> data type
     * @return a list of a <code>Gallery</code>. It is a <code>java.util.List</code>
     * @throws Exception 
     */
    public List<Galery> getListGaleryWithPaging(int pageIndex, int pageSize) throws Exception;
    
    
    
//    public void updateView(int id)throws Exception;
//
//    /**
//     *
//     * @param id
//     * @return
//     * @throws Exception
//     */
//    public int getView(int id) throws Exception;
}
