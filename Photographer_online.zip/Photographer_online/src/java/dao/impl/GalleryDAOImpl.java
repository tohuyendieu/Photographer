/**
 * Copyright(C) 2020, Tô Huyền Diệu
 * J3.L.P0017/ Photographer
 *
 * Record of change
 * DATE            AUTHOR              DESCRIPTION
 * 2020/02/25      Tô Huyền Diệu       Gallery DAO Implement
 */
package dao.impl;

import context.DBContext;
import entity.Galery;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import dao.GalleryDAO;

/**
 * The class list method select information from Gallery table in database.
 * The method will throw an object of <code> java.lang.Exception</code> class 
 * if there is any error occurring when selecting or updating data
 * 
 * @author Tô Huyền Diệu
 */
public class GalleryDAOImpl extends DBContext implements GalleryDAO {

    /**
     * Constructor method. It is extends DBContext
     * @throws ClassNotFoundException
     * @throws SQLException 
     */
    public GalleryDAOImpl() throws ClassNotFoundException, SQLException {
    }

    /**
     * Select amount of Gallery from Gallery table in database
     * The result contains a number. It is a <code>int</code> data type  
     * 
     * @return a number. It is a <code>int</code> data type
     * @throws Exception 
     */
    @Override
    public int count() throws Exception {
        Connection conn = null;
        PreparedStatement pr = null;
        ResultSet rs = null;
        try {
            String query = "SELECT count(*) from galery";
            conn = getConnection();
            pr = conn.prepareStatement(query);
            rs = pr.executeQuery();
            int cout = 0;
            while (rs.next()) {
                cout = rs.getInt(1);
            }
            return cout;
        } catch (ClassNotFoundException | SQLException ex) {
            throw ex;
        } finally {
            closeResusult(rs);
            closePreparedStatement(pr);
            closeConnection(conn);
        }
    }

    /**
     * Select top 3 Gallery from Gallery table in database. All information of Gallery will be return
     * The result contains a list of <code>Gallery</code> object 
     * 
     * @return a list of <code>Gallery</code> object. It is a <code>java.util.List</code> object
     * @throws Exception 
     */
    @Override
    public List<Galery> getTop3Galery() throws Exception {
        Connection conn = null;
        PreparedStatement pr = null;
        ResultSet rs = null;
        List<Galery> listGalery = new ArrayList<>();
        try {
            String query = "SELECT TOP 3* FROM [galery]";
            conn = getConnection();
            pr = conn.prepareStatement(query);
            rs = pr.executeQuery();
            while (rs.next()) {
                Galery galery = new Galery();
                galery.setID(rs.getInt("ID"));
                galery.setTitle(rs.getString("title"));
                galery.setDescription(rs.getString("description"));
                galery.setName(rs.getString("name"));
                listGalery.add(galery);
            }

        } catch (ClassNotFoundException | SQLException ex) {
            throw ex;
        } finally {
            closeResusult(rs);
            closePreparedStatement(pr);
            closeConnection(conn);
        }
        return listGalery;
    }

   /**
     * Select Gallery by its it. All information of Gallery will be return
     * The result contains a <code>Gallery</code> object with id, title, description, image
     * 
     * @param id the gallery id. It is a <code>int</code> data type
     * @return a <code>Gallery</code>. It is a <code>entity.Galery</code> object
     * @throws Exception 
     */
    @Override
    public Galery getGaleryByID(int id) throws Exception {
        Connection conn = null;
        PreparedStatement pr = null;
        ResultSet rs = null;
        try {
            String query = "SELECT top 1 * from galery where ID = ?";
            conn = getConnection();
            pr = conn.prepareStatement(query);
            pr.setInt(1, id);
            rs = pr.executeQuery();
            while (rs.next()) {
                Galery galery = new Galery();
                galery.setID(rs.getInt("ID"));
                galery.setTitle(rs.getString("title"));
                galery.setDescription(rs.getString("description"));
                galery.setName(rs.getString("name"));
                return galery;
            }

        } catch (ClassNotFoundException | SQLException ex) {
            throw ex;
        } finally {
            closeResusult(rs);
            closePreparedStatement(pr);
            closeConnection(conn);
        }
        return null;
    }

    /**
     * Select list Gallery by page index and page size.
     * The result contains a list of<code>Gallery</code>
     * 
     * @param pageIndex the page index. It is a <code>int</code> data type
     * @param pageSize the page size. It is a <code>int</code> data type
     * @return a list of a <code>Gallery</code>. It is a <code>java.util.List</code>
     * @throws Exception 
     */
    @Override
    public List<Galery> getListGaleryWithPaging(int pageIndex, int pageSize) throws Exception {
        Connection conn = null;
        PreparedStatement pr = null;
        ResultSet rs = null;
        List<Galery> list = new ArrayList<>();
        int size = count();
        try {
            String query = "select * from ( select ROW_NUMBER() over (order by id ASC) as rn , * from  galery )"
                    + "as b where rn between (?-1)*?+1 and ?*?";
            conn = getConnection();
            pr = conn.prepareStatement(query);
            pr.setInt(1, pageIndex);
            pr.setInt(2, pageSize);
            pr.setInt(3, pageIndex);
            pr.setInt(4, pageSize);
            rs = pr.executeQuery();
            while (rs.next()) {
                Galery galery = new Galery();
                galery.setID(rs.getInt("ID"));
                galery.setTitle(rs.getString("title"));
                galery.setDescription(rs.getString("description"));
                galery.setName(rs.getString("name"));
                list.add(galery);
            }
        } catch (ClassNotFoundException | SQLException ex) {
            throw ex;
        } finally {
            closeResusult(rs);
            closePreparedStatement(pr);
            closeConnection(conn);
        }
        return list;
    }

//    @Override
//    public void updateView(int id) throws Exception {
//        Connection conn = null;
//        PreparedStatement statement = null;
//        ResultSet result = null;
//        String sql = "UPDATE [galery]\n"
//                + "SET [view] = [view]+1\n"
//                + "WHERE [ID] = ?";
//        try {
//            conn = getConnection();
//            statement = conn.prepareStatement(sql);
//            statement.setInt(1, id);
//            statement.executeUpdate();
//        } catch (ClassNotFoundException | SQLException e) {
//            throw e;
//        } finally{
//            closeResusult(result);
//            closePreparedStatement(statement);
//            closeConnection(conn);
//        }
//    }

 //   @Override
//    public int getView(int id) throws Exception {
//        String sql = "SELECT [view] FROM [galery]\n"
//                + "WHERE [ID] = ?";
//        Connection conn = null;
//        PreparedStatement statement = null;
//        ResultSet result = null;
//        try {
//            conn = getConnection();
//            statement = conn.prepareStatement(sql);
//            statement.setInt(1, id);
//            result = statement.executeQuery();
//            if(result.next()) return result.getInt(1);
//        } catch (ClassNotFoundException | SQLException e) {
//        } finally{
//            closeResusult(result);
//            closePreparedStatement(statement);
//            closeConnection(conn);
//        }
//        return 0;
//    }
}
