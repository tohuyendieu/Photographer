/**
 * Copyright(C) 2020, Tô Huyền Diệu
 * J3.L.P0017/ Photographer
 *
 * Record of change
 * DATE            AUTHOR              DESCRIPTION
 * 2020/03/03      Tô Huyền Diệu       Photo DAO Implement
 */
package dao.impl;

import context.DBContext;
import entity.Image;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import dao.ImageDAO;

/**
 * The class list method select information from Image table in database.
 * The method will throw an object of <code> java.lang.Exception</code> class 
 * if there is any error occurring when selecting or updating data
 * 
 * @author Tô Huyền Diệu
 */
public class ImageDAOImpl extends DBContext implements ImageDAO {

    /**
     * Constructor method. It is extends DBContext
     * @throws ClassNotFoundException
     * @throws SQLException 
     */
   public ImageDAOImpl() throws ClassNotFoundException, SQLException {
    } 
   
   /**
     * Select amount of Image by GalleryId from table Image in database.
     * The result contains a number. It is a <code>int</code> data type 
     * 
     * @param id the Gallery id. It is a <code>int</code> data type
     * @return a number. It is a <code>int</code> data type 
     * @throws Exception 
     */
    @Override
    public int countImage(int id) throws Exception {
        Connection conn = null;
        PreparedStatement pr = null;
        ResultSet rs = null;
        try {
            String query = "SELECT count(*) from image where galery_id = ?";
            conn = getConnection();
            pr = conn.prepareStatement(query);
            pr.setInt(1, id);
            rs = pr.executeQuery();
            int cout = 0;
            while (rs.next()) {
                cout = rs.getInt(1);
            }
            return cout;
        } catch (ClassNotFoundException | SQLException ex) {
            throw ex;
        } finally {
            closeResusult(rs);
            closePreparedStatement(pr);
            closeConnection(conn);
        }
    }

     /**
     * Select top 1 link image by gallery id from table Image in database
     * The result contains a string is link of image. It is a <code>java.lang.String</code>
     * 
     * @param id the Gallery id. It is a <code>int</code> data type
     * @return a String. It is <code>java.lang.String</code> object
     * @throws Exception 
     */
    @Override
    public String getImageByGaleryID(int id) throws Exception {
        Connection conn = null;
        PreparedStatement pr = null;
        ResultSet rs = null;
        try {
            String query = "select top 1 image_url from image\n"
                    + "where galery_id = ?";
            conn = getConnection();
            pr = conn.prepareStatement(query);
            pr.setInt(1, id);
            rs = pr.executeQuery();
            while (rs.next()) {
                return rs.getString(1);
            }
        } catch (ClassNotFoundException | SQLException ex) {
            throw ex;
        } finally {
            closeResusult(rs);
            closePreparedStatement(pr);
            closeConnection(conn);
        }
        return null;
    }
    
    /**
     * Select list Image by gallery id, page index and page size from table Image in database Photo.
     * The result contains a list of <code>Image</code> object
     * 
     * @param galeryID the gallery id. It is a <code>int</code> data type
     * @param pageIndex the page index. It is a <code>int</code> data type
     * @param pageSize the page size. It is a <code>int</code> data type
     * @return a list of <code>Image</code>. It is a <code>java.util.List</code> object
     * @throws Exception 
     */
    @Override
    public List<Image> getListImageWithPaging(int galeryID, int pageIndex, int pageSize) throws Exception {
        Connection conn = null;
        PreparedStatement pr = null;
        ResultSet rs = null;
        List<Image> list = new ArrayList<>();
        int size = countImage(galeryID);
        try {
            String query = "select * from ( select ROW_NUMBER() over (order by id ASC) as rn , * from  image where galery_id = ?) "
                    + "as b where rn between ((?*?) - ?)and (?*?)";
            conn = getConnection();
            pr = conn.prepareStatement(query);
            pr.setInt(1, galeryID);
            pr.setInt(2, pageSize);
            pr.setInt(3, pageIndex);
            pr.setInt(4, pageSize - 1);
            pr.setInt(5, pageSize);
            pr.setInt(6, pageIndex);
            rs = pr.executeQuery();
            while (rs.next()) {
                Image image = new Image();
                image.setId(rs.getInt("ID"));
                image.setGaleryID(rs.getInt("galery_id"));
                image.setLink(rs.getString("image_url"));
                list.add(image);
            }
        } catch (ClassNotFoundException | SQLException ex) {
            throw ex;
        } finally {
            closeResusult(rs);
            closePreparedStatement(pr);
            closeConnection(conn);
        }
        return list;
    }
    
     /**
     * Select Image by Image id and gallery id from Image table in database.All information of a Image will be return 
     * The result contains a <code>Image</code> object with id, galleryID, link
     * 
     * @param id the Image id. It is a <code>int</code> data type
     * @param galeryId the gallery id. It is a <code>int</code> data type
     * @return a <code>Image</code> object. It is a <code>entity.Image</code>
     * @throws Exception 
     */
    @Override
    public Image getImageID(int id, int galeryId) throws Exception {
        Connection conn = null;
        PreparedStatement pr = null;
        ResultSet rs = null;
        try {
            String query = "SELECT * from image where id = ? and galery_id = ?";
            conn = getConnection();
            pr = conn.prepareStatement(query);
            pr.setInt(1, id);
            pr.setInt(2, galeryId);
            rs = pr.executeQuery();
            while (rs.next()) {
                Image image = new Image();
                image.setId(rs.getInt("ID"));
                image.setGaleryID(rs.getInt("galery_id"));
                image.setLink(rs.getString("image_url"));
                return image;
            }

        } catch (ClassNotFoundException | SQLException ex) {
            throw ex;
        } finally {
            closeResusult(rs);
            closePreparedStatement(pr);
            closeConnection(conn);
        }
        return null;
    }
    
    /**
     * Select top 1 Image by gallery id. All information of Image will be return
     * The result contains a <code>Image</code> object with id, galleryID, link
     * 
     * @param galeryID the gallery id. It is a <code>int</code> data type
     * @return <code>Image</code> object. It is a <code>entity.Image</code>
     * @throws Exception 
     */
    @Override
    public Image getTop1ImageGalery(int galeryID) throws Exception {
        Connection conn = null;
        PreparedStatement pr = null;
        ResultSet rs = null;
        try {
            String query = "SELECT top 1 * from image where galery_id = ?";
            conn = getConnection();
            pr = conn.prepareStatement(query);
            pr.setInt(1, galeryID);
            rs = pr.executeQuery();
            while (rs.next()) {
                Image image = new Image();
                image.setId(rs.getInt("ID"));
                image.setGaleryID(rs.getInt("galery_id"));
                image.setLink(rs.getString("image_url"));
                return image;
            }

        } catch (ClassNotFoundException | SQLException ex) {
            throw ex;
        } finally {
            closeResusult(rs);
            closePreparedStatement(pr);
            closeConnection(conn);
        }
        return null;
    }
}
