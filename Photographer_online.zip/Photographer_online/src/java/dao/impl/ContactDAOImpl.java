/**
 * Copyright(C) 2020, Tô Huyền Diệu
 * J3.L.P0017/ Photographer
 *
 * Record of change
 * DATE            AUTHOR              DESCRIPTION
 * 2020/02/25      Tô Huyền Diệu       Contact DAO Implement
 */
package dao.impl;

import context.DBContext;
import dao.ContactDAO;
import entity.Contact;
import entity.Galery;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 * The class list method select information from Gallery table in database.
 * The method will throw an object of <code> java.lang.Exception</code> class 
 * if there is any error occurring when selecting or updating data
 * 
 * @author Tô Huyền Diệu
 */
public class ContactDAOImpl extends DBContext implements ContactDAO {

    /**
     * Constructor method. It is extends DBContext
     * @throws ClassNotFoundException
     * @throws SQLException 
     */
    public ContactDAOImpl() throws ClassNotFoundException, SQLException {
    }

     /**
     * Select Contact from Contact table in database. All information of contact will be return
     * The result contains a Contact with telephone, email, linkFace, link Googgle, shortIntro,
     *           address, city, country, linkMap, imageMain, iconFace, iconTwitter, iconGoogle, views
     * 
     * @return a <code>Contact</code> object. It is a <code>entity.Contact</code>
     * @throws Exception 
     */
    @Override
    public Contact getContact() throws Exception {
        Connection conn = null;
        PreparedStatement pr = null;
        ResultSet rs = null;
        List<Galery> listGalery = new ArrayList<>();
        try {
            String query = "SELECT top 1 * from contact";
            conn = getConnection();
            pr = conn.prepareStatement(query);
            rs = pr.executeQuery();
            while (rs.next()) {
                Contact contact = new Contact();
                contact.setTelephone(rs.getString("telephone"));
                contact.setEmail(rs.getString("email"));
                contact.setLinkFace(rs.getString("face_url"));
                contact.setLinkTwitter(rs.getString("twitter_url"));
                contact.setLinkGoogle(rs.getString("google_url"));
                contact.setShortIntro(rs.getString("about"));
                contact.setAddress(rs.getString("address"));
                contact.setCity(rs.getString("city"));
                contact.setCountry(rs.getString("country"));
                contact.setLinkMap(rs.getString("map_url"));
                contact.setImageMain(rs.getString("image_main"));
                contact.setIconFace(rs.getString("icon_face"));
                contact.setIconTwitter(rs.getString("icon_twitter"));
                contact.setIconGoogle(rs.getString("icon_google"));
                return contact;
            }

        } catch (ClassNotFoundException | SQLException ex) {
            throw ex;
        } finally {
            closeResusult(rs);
            closePreparedStatement(pr);
            closeConnection(conn);
        }
        return null;
    }

    /**
     * Update views in Contact table in database. Create 1 view
     * 
     * @throws Exception 
     */
    @Override
    public void updateView() throws Exception {
        Connection conn = null;
        PreparedStatement statement = null;
        ResultSet result = null;
        String sql = "UPDATE [Contact]\n"
                + "SET [views] = [views] + 1";
        try {
            conn = getConnection();
            statement = conn.prepareStatement(sql);
            statement.executeUpdate();
        } catch (ClassNotFoundException | SQLException e) {
            throw e;
        } finally {
            closeResusult(result);
            closePreparedStatement(statement);
            closeConnection(conn);
        }
    }

    /**
     * Select amount of views from Contact table in database
     * The result return amount of views
     * 
     * @return a number. It is <code>int</code> data type
     * @throws Exception 
     */
    @Override
    public int getViews() throws Exception {
        String sql = "SELECT [views] FROM [Contact]";
        Connection conn = null;
        PreparedStatement statement = null;
        ResultSet result = null;
        try {
            conn = getConnection();
            statement = conn.prepareStatement(sql);
            result = statement.executeQuery();
            if (result.next()) {
                return result.getInt(1);
            }
        } catch (ClassNotFoundException | SQLException e) {
            throw e;
        } finally {
            closeResusult(result);
            closePreparedStatement(statement);
            closeConnection(conn);
        }
        return 0;
    }
}
