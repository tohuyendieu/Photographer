/**
 * Copyright(C) 2020, Tô Huyền Diệu
 * J3.L.P0017/ Photographer
 *
 * Record of change
 * DATE            AUTHOR              DESCRIPTION
 * 2020/02/27     Tô Huyền Diệu       HttpSessionListener implement
 */
package session;

import dao.ContactDAO;
import dao.impl.ContactDAOImpl;
import java.util.ArrayList;
import java.util.List;
import javax.servlet.http.HttpSession;
import javax.servlet.http.HttpSessionEvent;
import javax.servlet.http.HttpSessionListener;

/**
 * The class contains method session created
 * @author Tô Huyền Diệu
 */
public class ViewCount implements HttpSessionListener {

    /**
     * Select views from database to set attribute in session and update views
     * into database
     *
     * @param se the HttpSessionEvent. It is a <code>javax.servlet.http.HttpSession</code> object
     */
    @Override
    public void sessionCreated(HttpSessionEvent se) {
        HttpSession session = se.getSession();
        try {
            ContactDAO contactDAO = new ContactDAOImpl();
            contactDAO.updateView();
          //  int view = contactDAO.getViews();   
          //  session.setAttribute("view", view);
            String viewTotal = String.format("%06d", contactDAO.getViews());
            System.out.println(viewTotal);
            session.setAttribute("viewTotal", viewTotal);
        } catch (Exception e) {
            session.setAttribute("error", e);
        }
    }

    @Override
    public void sessionDestroyed(HttpSessionEvent se) {
    }

}
