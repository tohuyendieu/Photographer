/**
 * Copyright(C) 2020, Tô Huyền Diệu
 * J3.L.P0017/ Photographer
 *
 * Record of change
 * DATE            AUTHOR              DESCRIPTION
 * 2020/02/25      Tô Huyền Diệu       Gallery Entity
 */
package entity;

import dao.impl.ImageDAOImpl;
import dao.ImageDAO;

/**
 * The class contains method constructor, getter and setter 
 * 
 * @author Tô Huyền Diệu
 */
public class Galery {
    private int ID;
    private String title;
    private String description;
    private String name;
    private String image;
    
    /**
     * Constructor with no parameter
     */
    public Galery() {
    }

    /**
     * Constructor with parameter 
     * @param ID the Gallery id. It is a <code>int</code> data type
     * @param title the Gallery title. It is a <code>java.lang.String</code> object
     * @param description the Gallery description. It is a <code>java.lang.String</code> object
     */
    public Galery(int ID, String title, String description) {
        this.ID = ID;
        this.title = title;
        this.description = description;
    }

    /**
     * Constructor with full parameter 
     * @param ID the Gallery id. It is a <code>int</code> data type
     * @param title the Gallery title. It is a <code>java.lang.String</code> object
     * @param description the Gallery description. It is a <code>java.lang.String</code> object
     * @param name the Gallery name. It is a <code>java.lang.String</code> object
     * @param image the Gallery avatar. It is a <code>java.lang.String</code> object
     */
    public Galery(int ID, String title, String description, String name, String image) {
        this.ID = ID;
        this.title = title;
        this.description = description;
        this.name = name;
        this.image = image;
    }

    /**
     * Get Image of Gallery
     * @return link of photo storage. It is a <code>java.lang.String</code> object
     * @throws Exception 
     */
    public String getImage() throws Exception {
        ImageDAO dao = new ImageDAOImpl();
        return dao.getImageByGaleryID(ID);
    }

    /**
     * Set Image of Gallery
     * @param image link of photo storage. It is a <code>java.lang.String</code> object
     */
    public void setImage(String image) {
        this.image = image;
    }

    /**
     * Get name of author.
     * @return name of author. It is a <code>java.lang.String</code> object
     */
    public String getName() {
        return name;
    }

    /**
     * Set author's name
     * @param name the name of author. It is a <code>java.lang.String</code> object
     */
    public void setName(String name) {
        this.name = name;
    }
    
    /**
     * Get Gallery id. 
     * The result contain id of Gallery
     * 
     * @return id is a <code>int</code> data type
     */
    public int getID() {
        return ID;
    }

    /**
     * Set Gallery id.
     * @param ID is a <code>int</code> data type
     */
    public void setID(int ID) {
        this.ID = ID;
    }

    /**
     * Get Gallery title.
     * The result contains title of Gallery
     * 
     * @return title of Gallery . It is a <code>java.lang.String</code> object
     */
    public String getTitle() {
        return title;
    }

    /**
     * Set Gallery title
     * @param title the title of Gallery . It is a <code>java.lang.String</code> object
     */
    public void setTitle(String title) {
        this.title = title;
    }

    /**
     * Get Gallery description.
     * The result contains description of Gallery
     * 
     * @return description of Gallery . It is a <code>java.lang.String</code> object
     */
    public String getDescription() {
        return description;
    }

    /**
     * Set Gallery description
     * @param description the description of Gallery . It is a <code>java.lang.String</code> object
     */
    public void setDescription(String description) {
        this.description = description;
    }
//
//    @Override
//    public String toString() {
//        return "Galery{" + "ID=" + ID + ", title=" + title + ", description=" + description + '}';
//    }
    

}
