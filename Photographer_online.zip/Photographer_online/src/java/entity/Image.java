/**
 * Copyright(C) 2020, Tô Huyền Diệu
 * J3.L.P0017/ Photographer
 *
 * Record of change
 * DATE            AUTHOR              DESCRIPTION
 * 2020/02/25      Tô Huyền Diệu       Image Entity
 */
package entity;

/**
 * The class contains method constructor, getter and setter 
 * 
 * @author Tô Huyền Diệu
 */
public class Image {

    private int id;
    private int galeryID;
    private String link;

    /**
     * Constructor with no parameter
     */
    public Image() {
    }

    /**
     * Constructor with full parameter
     * 
     * @param id the Image id. It is a <code>int</code> data type
     * @param galeryId the Gallery id. It is a <code>int</code> data type
     * @param linkImage the place where contains image. It is a <code>java.lang.String</code>
     */
    public Image(int id, int galeryId, String linkImage) {
        this.id = id;
        this.galeryID = galeryId;
        this.link = linkImage;
    }

    /**
     * Get id of Image. The result contains id of Image
     * 
     * @return a number. It is a <code>int</code> data type
     */
    public int getId() {
        return id;
    }

    /**
     * Set id for Image.
     * 
     * @param id the id of Image. It is a <code>int</code> data type 
     */
    public void setId(int id) {
        this.id = id;
    }

    /**
     * Get id of Gallery. The result contains id of Gallery
     * 
     * @return a number. It is a <code>int</code> data type
     */
    public int getGaleryID() {
        return galeryID;
    }

    /**
     * Set id for Gallery.
     * 
     * @param galeryID the id of Gallery. It is a <code>int</code> data type 
     */
    public void setGaleryID(int galeryID) {
        this.galeryID = galeryID;
    }

     /**
     * Get link of Image. The result contains link of Image
     * 
     * @return a string. It is a <code>java.lang.String</code> object
     */
    public String getLink() throws Exception {
        return link;
    }

    /**
     * Set link for Image.
     * 
     * @param link the link of Image. It is a <code>java.lang.String</code> object
     */
    public void setLink(String link) {
        this.link = link;
    }
    
    
}
