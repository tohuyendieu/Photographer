/**
 * Copyright(C) 2020, Tô Huyền Diệu
 * J3.L.P0017/ Photographer
 *
 * Record of change
 * DATE            AUTHOR              DESCRIPTION
 * 2020/02/25      Tô Huyền Diệu       Contact Entity
 */

package entity;

/**
 * The class contains method constructor, getter and setter 
 * 
 * @author Tô Huyền Diệu
 */
public class Contact {

    private String telephone;
    private String email;
    private String linkFace;
    private String linkTwitter;
    private String linkGoogle;
    private String shortIntro; 
    private String address;
    private String city;
    private String country;
    private String linkMap;
    private String imageMain;
    private String iconFace;
    private String iconTwitter;
    private String iconGoogle;
    private int views;

    /**
     * Constructor with no parameter
     */
    public Contact() {
    }

    /**
     * Get amount of views. 
     * The result contains a number
     * 
     * @return views of page. It is a <code>int</code> data type
     */
    public int getViews() {
        return views;
    }

    /**
     * Set amount of views
     * 
     * @param views views of page. It is a <code>int</code> data type
     */
    public void setViews(int views) {
        this.views = views;
    }

    /**
     * Get icon Facebook.
     * The result contains where contains the icon.
     * 
     * @return a string. It is a <code>java.lang.String</code>
     * @throws Exception 
     */
    public String getIconFace() throws Exception {
        return iconFace;
    }

    /**
     * Set icon FaceBook
     * @param iconFace the place contains the icon.It is a <code>java.lang.String</code>
     */
    public void setIconFace(String iconFace) {
        this.iconFace = iconFace;
    }

    /**
     * Get icon twitter.
     * The result contains where contains the icon.
     * 
     * @return a string. It is a <code>java.lang.String</code>
     * @throws Exception 
     */
    public String getIconTwitter() throws Exception {
        return iconTwitter;
    }

    
     /**
     * Set icon twitter
     * 
     * @param  iconTwitter the place contains the icon.It is a <code>java.lang.String</code>
     */
    public void setIconTwitter(String iconTwitter) {
        
        this.iconTwitter = iconTwitter;
    }

    /**
     * Get icon Google.
     * The result contains where contains the icon.
     * 
     * @return a string. It is a <code>java.lang.String</code>
     * @throws Exception 
     */
    public String getIconGoogle() throws Exception {
        return iconGoogle;
    }

    /**
     * Set icon Google
     * @param iconGoogle the place contains the icon.It is a <code>java.lang.String</code>
     */
    public void setIconGoogle(String iconGoogle) {
        this.iconGoogle = iconGoogle;
    }

    /**
     * Get image.
     * The result contains where contains the image.
     * 
     * @return a string. It is a <code>java.lang.String</code>
     * @throws Exception 
     */
    public String getImageMain() throws Exception {
        return imageMain;
    }

    /**
     * Set where contains the image
     * @param imageMain is a <code>java.lang.String</code>
     */
    public void setImageMain(String imageMain) {
        this.imageMain = imageMain;
    }

    /**
     * Get telephone of page
     * The result contains telephone number of page
     * 
     * @return a <code>java.lang.String</code>
     */
    public String getTelephone() {
        return telephone;
    }

     /**
     * Set telephone of page
     * @param telephone is a <code>java.lang.String</code>
     */
    public void setTelephone(String telephone) {
        this.telephone = telephone;
    }

    /**
     * Get email of page
     * The result contains email number of page
     * 
     * @return a <code>java.lang.String</code>
     */
    public String getEmail() {
        return email;
    }

    /**
     * Set email of page
     * @param email is a <code>java.lang.String</code>
     */
    public void setEmail(String email) {
        this.email = email;
    }

    /**
     * Get link Facebook of page
     * The result contains link Facebok number of page
     * 
     * @return a <code>java.lang.String</code>
     */
    public String getLinkFace() {
        return linkFace;
    }

    /**
     * Set email of page
     * @param linkFace is a <code>java.lang.String</code>
     */
    public void setLinkFace(String linkFace) {
        this.linkFace = linkFace;
    }

    /**
     * Get link Twitter of page
     * The result contains link Twitter number of page
     * 
     * @return a <code>java.lang.String</code>
     */
    public String getLinkTwitter() {
        return linkTwitter;
    }

    /**
     * Set email of page
     * @param linkTwitter is a <code>java.lang.String</code>
     */
    public void setLinkTwitter(String linkTwitter) {
        this.linkTwitter = linkTwitter;
    }

    /**
     * Get link Google
     * The result contains link Google
     * 
     * @return a <code>java.lang.String</code>
     */
    public String getLinkGoogle() {
        return linkGoogle;
    }

    /**
     * Set link google
     * @param linkGoogle is a <code>java.lang.String</code>
     */
    public void setLinkGoogle(String linkGoogle) {
        this.linkGoogle = linkGoogle;
    }

     /**
     * Get short introduction
 The result contains short introduction shortIntro page
     * 
     * @return a <code>java.lang.String</code>
     */
    public String getShortIntro() {
        return shortIntro;
    }

    /**
     * Set short introduction
     * @param shortIntro is a <code>java.lang.String</code>
     */
    public void setShortIntro(String shortIntro) {
        this.shortIntro = shortIntro;
    }

    /**
     * Get address
     * The result contains address
     * 
     * @return a <code>java.lang.String</code>
     */
    public String getAddress() {
        return address;
    }

    /**
     * Set address
     * @param address is a <code>java.lang.String</code>
     */
    public void setAddress(String address) {
        this.address = address;
    }

   /**
     * Get city name
     * The result contains city name
     * 
     * @return a <code>java.lang.String</code>
     */
    public String getCity() {
        return city;
    }

     /**
     * Set city
     * @param city is a <code>java.lang.String</code>
     */
    public void setCity(String city) {
        this.city = city;
    }

    /**
     * Get country name
     * The result contains country name
     * 
     * @return a <code>java.lang.String</code>
     */
    public String getCountry() {
        return country;
    }

     /**
     * Set country
     * @param country is a <code>java.lang.String</code>
     */
    public void setCountry(String country) {
        this.country = country;
    }

     /**
     * Get link google map
     * The result contains link google map
     * 
     * @return a <code>java.lang.String</code>
     */
    public String getLinkMap() {
        return linkMap;
    }

     /**
     * Set link google map
     * @param linkMap is a <code>java.lang.String</code>
     */
    public void setLinkMap(String linkMap) {
        this.linkMap = linkMap;
    }

}
